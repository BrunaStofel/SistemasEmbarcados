//---------------------------------------------------------------------------
#pragma hdrstop

#include "PortaSerial.h"
#include <vector.h>
#include "USerialCommunication.h"

//---------------------------------------------------------------------------

SerialPort::SerialPort()
{
    //Vari�vel que que receber� a porta serial aberta.
    hComm = NULL;

    //Valores padr�o.
    BaudRate = CBR_115200;  // CBR_38400, CBR_9600
    Parity   = NOPARITY;    // 0 - 4 = no, odd, even, mark, space
    StopBits = ONESTOPBIT;  // 0 - 2 = 1, 1.5, 2
    ByteSize = 8;

    //Configura��o dos tamanhos dos buffers de leitura e escrita.
    dwToRead = 256;
}
//---------------------------------------------------------------------------

vector <AnsiString> SerialPort::CheckSerialPort()
{
    HANDLE hCommCheck;
    AnsiString asCommPort;
    AnsiString asPort;
    vector <AnsiString> asDetectedPorts;

    //Realiza a verifica��o das portas seriais de COM1 a COM30.
    for (int a = 1; a < 50; a++)
    {
        //Verifica se h� uma porta serial ainda aberta.
        if (hCommCheck != NULL)
        {
            //Fecha a porta serial.
    		CloseHandle(hCommCheck);
            hCommCheck = NULL;
        }

        //Monta o nome da porta de acordo com o �ndice selecionado.
        asPort = "COM" + IntToStr(a);

        //Configura��o do nome da porta serial a ser aberta.
        asCommPort = "\\\\.\\" + asPort;

        //Abertura da porta serial selecionada.
        hCommCheck = CreateFile( asCommPort.c_str(),     	// ponteiro para a porta selecionada.
                            GENERIC_READ | GENERIC_WRITE,	// Modo de acesso (escrita ou leitura).
                            0,	                            // N�o utilizado.
                            0,	                            // N�o utilizado.
                            CREATE_ALWAYS,              	// Como a porta ser� criada.
                            NULL,                       	// N�o utilizado.
                            0);                             // N�o utilizado.

        //Faz a verifica��o se a porta foi aberta corretamente.
    	if (hCommCheck != INVALID_HANDLE_VALUE)
        {
            asDetectedPorts.push_back(asPort);
        }
    }

    //Fecha a porta serial aberta.
    if (hCommCheck != NULL)
    {
        SetCommMask(hCommCheck, 0L);

        CloseHandle(hCommCheck);
        hCommCheck = NULL;
    }


    //Retorna as portas seriais detectadas.
    return (asDetectedPorts);
}

//---------------------------------------------------------------------------

BOOL SerialPort::OpenSerialPort(AnsiString asPort, AnsiString asBaudRate)
{
    AnsiString asCommPort;

    //Verifica se h� uma porta serial ainda aberta caso exista ela � fechada.
    if (hComm != NULL)
    {
        //Fecha a porta serial.
		CloseHandle(hComm);
        hComm = NULL;
    }

    //Configura��o do nome da porta serial selecionada.
    asCommPort = "\\\\.\\" + asPort;

    //Configura��es do Baud Rate da porta serial selecionada.
    if (asBaudRate == "256000") BaudRate = CBR_256000;
    if (asBaudRate == "128000") BaudRate = CBR_128000;
    if (asBaudRate == "115200") BaudRate = CBR_115200;
    if (asBaudRate == "57600")  BaudRate = CBR_57600;
    if (asBaudRate == "56000")  BaudRate = CBR_56000;
    if (asBaudRate == "38400")  BaudRate = CBR_38400;
    if (asBaudRate == "19200")  BaudRate = CBR_19200;
    if (asBaudRate == "14400")  BaudRate = CBR_14400;
    if (asBaudRate == "9600")   BaudRate = CBR_9600;
    if (asBaudRate == "4800")   BaudRate = CBR_4800;
    if (asBaudRate == "2400")   BaudRate = CBR_2400;
    if (asBaudRate == "1200")   BaudRate = CBR_1200;

    //Abertura da porta serial selecionada.
    hComm = CreateFile( asCommPort.c_str(),     	    // ponteiro para a porta selecionada.
                        GENERIC_READ | GENERIC_WRITE,	// Modo de acesso (escrita ou leitura).
                        0,	                            // N�o utilizado.
                        0,	                            // N�o utilizado.
                        CREATE_ALWAYS,              	// Como a porta ser� criada.
                        NULL,                       	// N�o utilizado.
                        0);                             // N�o utilizado.

    //Faz a verifica��o se a porta foi aberta corretamente.
	if (hComm != INVALID_HANDLE_VALUE)
    {
        //Configura��o dos Timeouts da Porta Serial.
        COMMTIMEOUTS CommTimeouts;

        //Atribui��o dos valores definidos para os Timeouts.
        CommTimeouts.ReadIntervalTimeout            = MAXDWORD;
        CommTimeouts.ReadTotalTimeoutMultiplier     = 0;
        CommTimeouts.ReadTotalTimeoutConstant       = 0;
        CommTimeouts.WriteTotalTimeoutMultiplier    = 0;
        CommTimeouts.WriteTotalTimeoutConstant      = 0;

        //Verifica��o se os par�metros de configura��o foram aceitos.
        if (SetCommTimeouts(hComm, &CommTimeouts) == 0)
        {
            ShowMessage("ERRO AO ALTERAR DADOS DE CONFIGURA��O DA PORTA SERIAL" + asPort);
            CloseHandle(hComm);
            hComm = NULL;

            return (false);
        }

        //Configura��es dos par�metros de funcionamento da Porta Serial.
        DCB dcb = {0};

        //Verifica��o se foi poss�vel obter os par�metros de configura��o originais da Porta Serial.
        if (GetCommState(hComm, &dcb) == 0)
        {
            ShowMessage("ERRO AO OBTER DADOS DE CONFIGURA��O DA PORTA SERIAL" + asPort);
            CloseHandle(hComm);
            hComm = NULL;

            //Sinaliza erro na abertura da porta serial.
            return (false);
        }

        //Estrutura de configura��o da porta serial.
        dcb.DCBlength           = sizeof(dcb);  // sizeof(DCB)

        //Atribui��o dos par�metros (DEFAULT) de configura��o da Porta Serial.
        dcb.BaudRate            = BaudRate;     // current baud rate
        dcb.fBinary             = true;         // binary mode, no EOF check
        dcb.fParity             = true;         // enable parity checking
        dcb.ByteSize            = 8;            // number of bits/byte, 4-8
        dcb.Parity              = NOPARITY;     // 0 - 4 = no, odd, even, mark, space
        dcb.StopBits            = ONESTOPBIT;   // 0, 1, 2 = 1, 1.5, 2

        //Demais par�metros opcional.
        dcb.fOutxCtsFlow        = false;        // CTS output flow control
        dcb.fOutxDsrFlow        = false;        // DSR output flow control
        dcb.fDtrControl         = DTR_CONTROL_DISABLE;  // DTR flow control type
        dcb.fDsrSensitivity     = false;        // DSR sensitivity
        dcb.fTXContinueOnXoff   = false;        // XOFF continues Tx            2
        dcb.fOutX               = false;        // XON/XOFF out flow control
        dcb.fInX                = false;        // XON/XOFF in flow control
        dcb.fErrorChar          = false;        // enable error replacement     1
        dcb.fNull               = false;        // enable null stripping
        dcb.fRtsControl         = RTS_CONTROL_DISABLE;  // RTS flow control
        dcb.fAbortOnError       = false;        // abort reads/writes on error
        dcb.fDummy2             = false;        // reserved                     1
        dcb.XonLim              = 0;            // transmit XON threshold       1
        dcb.XoffLim             = 0;            // transmit XOFF threshold      1
        dcb.XonChar             = 0;            // Tx and Rx XON character
        dcb.XoffChar            = 0;            // Tx and Rx XOFF character
        dcb.ErrorChar           = 0;            // error replacement character
        dcb.EofChar;                            // end of input character
        dcb.EvtChar             = 0;
        //dcb.wReserved;                        // not currently used           1
        dcb.wReserved1;                         // reserved; do not use

        //Verifica��o se os par�metros de configura��o foram aceitos.
        if (SetCommState(hComm,&dcb) == 0)
        {
            ShowMessage("ERRO AO ALTERAR DADOS DE CONFIGURA��O DA PORTA SERIAL" + asPort);
            CloseHandle(hComm);
            hComm = NULL;

            return (false);
        }
    }
    else
    {
        ShowMessage("ERRO AO ABRIR A PORTA SERIAL" + asPort);
        CloseHandle(hComm);
        hComm = NULL;

        return (false);
    }

    //Descarta caracteres presentes na porta e termina processos pendentes de leitura e transmiss�o.
    PurgeComm(hComm, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR);

    return (true);
}

//---------------------------------------------------------------------------

BOOL SerialPort::WriteABuffer(char *Buffer, DWORD dwToWrite)
{
    OVERLAPPED osWrite = {0};

    if (hComm != NULL)
    {
        // Create this writes OVERLAPPED structure hEvent.
        osWrite.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

        if (osWrite.hEvent == NULL)
        {
            return (false);     // Error creating overlapped event handle.
        }

        if (!WriteFile(hComm, Buffer, dwToWrite, &dwWritten, &osWrite))
        {
            ShowMessage("ERRO AO ENVIAR DADOS PARA A PORTA SERIAL");
        }

        CloseHandle(osWrite.hEvent);
    }
    else
    {
        ShowMessage("ERRO AO ABRIR A PORTA SERIAL");
        CloseHandle(hComm);
        return (FALSE);
    }

    //Finaliza todas as pend�ncias de escrita e leitura da porta serial selecionada.
    PurgeComm(hComm, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR);

    return (true);
}

//---------------------------------------------------------------------------

char * SerialPort::ReadABuffer()
{
    OVERLAPPED osRead = {0};

    if (hComm != NULL)
    {
        // Create this writes OVERLAPPED structure hEvent.
        osRead.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

        if (osRead.hEvent != NULL)
        {
            strcpy(Buffer,"\x0");
            if (ReadFile(hComm, &Buffer, dwToRead, &dwRead, &osRead))
            {
                //Encerra corretamente a string para n�o retornar lixo.
                Buffer[dwRead] = '\0';
            }
            else
            {
                ShowMessage("ERRO AO LER DADOS DA PORTA SERIAL");
            }
        }
        else
        {
            ShowMessage("ERRO AO ABRIR A PORTA SERIAL");
            CloseHandle(hComm);
            return (FALSE);
        }

        CloseHandle(osRead.hEvent);
    }
    else
    {
        ShowMessage("ERRO AO ABRIR A PORTA SERIAL");
        CloseHandle(hComm);
//        return (FALSE);
    }

    //Finaliza todas as pend�ncias de escrita e leitura da porta serial selecionada.
    PurgeComm(hComm, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR);

    //Retorna o buffer recebido.
    return (Buffer);
}

//---------------------------------------------------------------------------

vector<unsigned char> SerialPort::ReadBuffer()
{
    std::vector <unsigned char> dest(256);

    OVERLAPPED osRead = {0};

    if (hComm != NULL)
    {
        // Create this writes OVERLAPPED structure hEvent.
        osRead.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
        if (osRead.hEvent != NULL)
        {
            strcpy(Buffer,"\x0");
            if (ReadFile(hComm, &Buffer, dwToRead, &dwRead, &osRead))
            {
                //Encerra corretamente a string para n�o retornar lixo.
                Buffer[dwRead] = '\0';
                memcpy(&dest[0], &Buffer[0], dwRead*sizeof(char));
            }
            else
            {
                ShowMessage("ERRO AO LER DADOS DA PORTA SERIAL");
            }
        }
        else
        {
            ShowMessage("ERRO AO ABRIR A PORTA SERIAL");
            CloseHandle(hComm);
            //return (FALSE);
        }
        
        CloseHandle(osRead.hEvent);
    }
    else
    {
        ShowMessage("ERRO AO ABRIR A PORTA SERIAL");
        CloseHandle(hComm);
        //return (FALSE);
    }

    //Finaliza todas as pend�ncias de escrita e leitura da porta serial selecionada.
    PurgeComm(hComm, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR);

    //Retorna o buffer recebido.
    return (dest);
}



//---------------------------------------------------------------------------
unsigned int SerialPort::getBufferSize()
{
    //Obt�m o n�mero de bytes no buffer serial a serem lidos.
    return (dwRead);
}

//---------------------------------------------------------------------------

void SerialPort::CloseSerialPort()
{
    //Fecha a porta serial aberta.
    if (hComm != NULL)
    {
        SetCommMask(hComm, 0L);

        CloseHandle(hComm);
        hComm = NULL;
    }
}

//---------------------------------------------------------------------------
#pragma package(smart_init)
